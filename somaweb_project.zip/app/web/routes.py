                           
from __future__ import annotations

import io
import re
import unicodedata
from pathlib import Path
from typing import Any, Dict, List

from flask import current_app, render_template, request, send_file
from jinja2 import TemplateNotFound
from reportlab.pdfgen import canvas

from app.pdf.base_layout import PageStyle
from app.pdf.pdf_factory import render_pdf, example_data

from . import web_bp


                           
         
                           
def _project_base_dir() -> str:
                                              
    return str(Path(current_app.root_path).resolve().parent)


def _render_any(names: List[str], **ctx):
    last_exc = None
    for name in names:
        try:
            return render_template(name, **ctx)
        except TemplateNotFound as e:
            last_exc = e
    raise last_exc or TemplateNotFound(names[0])


def _participant_areas_from_example(ex: Dict[str, Any]) -> List[str]:
    parts = ex.get("participants") or []
    areas: List[str] = []
    for p in parts:
        a = (p or {}).get("area")
        if a:
            areas.append(str(a))
    return areas


def _schema_from_example(ex: Dict[str, Any]) -> List[Dict[str, Any]]:
    return ex.get("sections") or []


def _iso_to_dmy(s: str) -> str:
    """Normaliza fecha YYYY-MM-DD (input date) a DD/MM/AAAA para PDF."""
    s = (s or "").strip()
    if len(s) == 10 and s[4] == "-" and s[7] == "-":
        try:
            y, m, d = s.split("-")
            if len(y) == 4 and len(m) == 2 and len(d) == 2:
                return f"{d}/{m}/{y}"
        except Exception:
            return s
    return s


_DOC_LABELS: Dict[str, str] = {
    "planning": "PLAN",
    "scheduling": "PROG",
    "post": "PMT",
    "prioritization": "PRIO",
    "process_5s": "P5S",
}



def _slug_filename_part(s: str) -> str:
    """Deja un string seguro para nombre de archivo (sin tildes, sin símbolos raros)."""
    s = (s or "").strip()
    if not s:
        return "SIN_DATO"
    s = unicodedata.normalize("NFKD", s)
    s = s.encode("ascii", "ignore").decode("ascii")
    s = re.sub(r"[^A-Za-z0-9]+", "_", s)
    s = re.sub(r"_+", "_", s).strip("_")
    return s or "SIN_DATO"


def _filename_from_data(doc_type: str, data: Dict[str, Any]) -> str:
    """Nombre: Gerencia-Area-TipoFormulario-Fecha.pdf

    Nota: en nombres de archivo no se usan '/', por compatibilidad se cambia a '-'.
    """
    observers = data.get("observers") or []
    g1 = (observers[0] or {}).get("gerencia") if len(observers) > 0 else ""
    g2 = (observers[1] or {}).get("gerencia") if len(observers) > 1 else ""
    gerencia = str(g1 or g2 or "SIN_GERENCIA")

    # Área del formulario (fallback: en 5S usar Sector/División si no existe 'area')
    area = str((data.get("area") or "")).strip()
    if not area:
        area = str((data.get("sector") or data.get("division") or "")).strip()
    if not area:
        area = "SIN_AREA"

    tipo = _DOC_LABELS.get(doc_type, doc_type).strip() or doc_type

    fecha = str((data.get("fecha") or "")).strip()
    # El usuario ingresa DD/MM/AAAA; para nombre de archivo usamos DD-MM-AAAA.
    fecha_safe = fecha.replace("/", "-").replace(" ", "")
    if not fecha_safe:
        fecha_safe = "SIN_FECHA"

    return (
        f"{_slug_filename_part(gerencia)}"
        f"-{_slug_filename_part(area)}"
        f"-{_slug_filename_part(tipo)}"
        f"-{_slug_filename_part(fecha_safe)}.pdf"
    )


def _parse_common_form(
    doc_type: str,
    form,
    schema: List[Dict[str, Any]],
    participant_areas: List[str],
) -> Dict[str, Any]:
    base = example_data(doc_type)

    data: Dict[str, Any] = {
        "title": base.get("title", ""),
        "fecha": _iso_to_dmy(form.get("fecha", "")),
        "hora": form.get("hora", ""),
        "area": form.get("area", ""),
        "observers": [
            {
                "id": form.get("obs1_id", ""),
                "nombre": form.get("obs1_nombre", ""),
                "gerencia": form.get("obs1_gerencia", ""),
                "superintendencia": form.get("obs1_superintendencia", ""),
                "sap": form.get("obs1_sap", ""),
                "email": form.get("obs1_email", ""),
                "posicion": form.get("obs1_posicion", ""),
            },
            {
                "id": form.get("obs2_id", ""),
                "nombre": form.get("obs2_nombre", ""),
                "gerencia": form.get("obs2_gerencia", ""),
                "superintendencia": form.get("obs2_superintendencia", ""),
                "sap": form.get("obs2_sap", ""),
                "email": form.get("obs2_email", ""),
                "posicion": form.get("obs2_posicion", ""),
            },
        ],
        "sections": [],
        "feedback": {
            "fortalezas": form.get("fortalezas", ""),
            "oportunidades": form.get("oportunidades", ""),
            "plan": form.get("plan", ""),
        },
        "commitments": [],
        "participants": [],
    }

                                            
    if doc_type == "process_5s":

                                            
        data["codigo"] = base.get("codigo", "")

                                            
        data["division"] = form.get("division", "")

                                            
        data["sector"] = form.get("sector", "")

                                            
        data["evaluador"] = form.get("evaluador", "")

                                            
        data["supervisor"] = form.get("supervisor", "")

                                            
        data["turno"] = form.get("turno", "")

                                            
        data["si_gerente"] = form.get("si_gerente", "")

        if not str(data["observers"][0].get("gerencia", "")).strip():
            data["observers"][0]["gerencia"] = data["si_gerente"]



                                            
    for si, sec in enumerate(schema):
        sec_out = {"name": sec.get("name", ""), "items": []}
        items = sec.get("items") or []

        for ii, it in enumerate(items):
            key = f"s{si}_i{ii}"
            raw = form.get(key, "")
            try:
                sel = int(raw) if (raw is not None and str(raw).strip() != "") else 1
            except Exception:
                sel = 1

            opts = it.get("options") or []
            if doc_type == "process_5s":
                if sel < 0 or sel > (len(opts) if opts else 0):
                    sel = 1
            else:
                sel = max(1, min(len(opts) if opts else 1, sel))

            sec_out["items"].append(
                {"question": it.get("question", ""), "options": opts, "selected": sel}
            )

        data["sections"].append(sec_out)

                          
    c_acc = form.getlist("c_accion[]") if hasattr(form, "getlist") else []
    c_resp = form.getlist("c_responsable[]") if hasattr(form, "getlist") else []
    c_fec = form.getlist("c_fecha[]") if hasattr(form, "getlist") else []
    c_est = form.getlist("c_estado[]") if hasattr(form, "getlist") else []
    c_evi = form.getlist("c_evidencia[]") if hasattr(form, "getlist") else []

    n = max(len(c_acc), len(c_resp), len(c_fec), len(c_est), len(c_evi))
    for i in range(n):
        row = {
            "accion": (c_acc[i] if i < len(c_acc) else "").strip(),
            "responsable": (c_resp[i] if i < len(c_resp) else "").strip(),
            "fecha": _iso_to_dmy((c_fec[i] if i < len(c_fec) else "")).strip(),
            "estado": (c_est[i] if i < len(c_est) else "").strip(),
            "evidencia": (c_evi[i] if i < len(c_evi) else "").strip(),
        }
        if any(row.values()):
            data["commitments"].append(row)

                                    
    for pi, area in enumerate(participant_areas):
        resp = (form.get(f"p_responsable_{pi}", "") or "").strip()
        asist = (form.get(f"p_asistio_{pi}", "") or "").strip().lower()
        data["participants"].append(
            {"area": area, "responsable": resp, "si": (asist == "si"), "no": (asist == "no")}
        )

    return data


def _build_pdf_bytes(doc_type: str, data: Dict[str, Any]) -> bytes:
    buf = io.BytesIO()
    style = PageStyle()
    c = canvas.Canvas(buf, pagesize=style.pagesize)
    render_pdf(doc_type, c, data, _project_base_dir())
    c.save()
    return buf.getvalue()


                           
                                       
                           
PRIORITIZATION_SCHEMA: List[Dict[str, Any]] = [
    {
        "name": "Aspectos generales",
        "items": [
            {
                "question": "Ejecución: La reunión…",
                "options": [
                    "No se realizó y/o se reagendó",
                    "Se realizó, pero tarde o se extendió",
                    "Se realizó de acuerdo con el horario y la duración planificada",
                ],
            },
            {
                "question": "Asistencia: A la reunión asisten... (planificación, confiabilidad, operación, ej. mantenimiento, abastecimiento, EECC y prevencionistas)",
                "options": [
                    "No se presentaron más de 3 participantes claves",
                    "Faltaron 1 -2 participantes claves",
                    "Estaban todos los relevantes",
                ],
            },
        ],
    },
    {
        "name": "Inputs",
        "items": [
            {
                "question": "Propuesta de confiabilidad (plan matriz y MonCon): Los ingenieros de confiabilidad y planificación...",
                "options": [
                    "No presentan una lista de actividades pre-priorizadas",
                    "Presentan una lista de actividades pre-priorizadas, pero no está hecha en SAP",
                    "Presentan una lista de actividades pre-priorizadas e identificadas en la plataforma SAP",
                ],
            },
            {
                "question": "Actividades fuera del sistema SAP:",
                "options": [
                    "Las otras áreas traen solicitudes de las tareas del sistema y SIN priorización",
                    "Las otras áreas traen una lista ya priorizada",
                    "No hay actividades propuestas fuera del sistema SAP",
                ],
            },
        ],
    },
    {
        "name": "Desarrollo",
        "items": [
            {
                "question": "Propuesta base de confiabilidad: El equipo…",
                "options": [
                    "No revisa en conjunto la propuesta base",
                    "La revisa en conjunto, pero no se solicita validación",
                    "Revisa en conjunto la propuesta base y se confirma el acuerdo",
                ],
            },
            {
                "question": "Inclusión de actividades no consideradas: Las actividades propuestas…",
                "options": [
                    "No son revisadas en conjunto y se incluyen directamente en el programa",
                    "Son presentadas, pero no se valida la priorización",
                    "Son revisadas en conjunto y se valida su priorización",
                ],
            },
            {
                "question": "Cambios en prioridad según nivel de riesgo discutido: El equipo…",
                "options": [
                    "No discute los niveles de riesgo de las actividades",
                    "Discute niveles de riesgo, pero no son considerados para la priorización",
                    "Discute niveles de riesgo y realiza cambios en las prioridades de acuerdo con ello",
                ],
            },
            {
                "question": "Cierre: Los ingenieros de confiabilidad y planificación…",
                "options": [
                    "No solicitan a los participantes la confirmación de la lista priorizada de tareas",
                    "Solicitan a los participantes la validación de la lista priorizada de tareas, pero no formalmente",
                    "Solicitan a los participantes la validación formal de la lista priorizada de tareas",
                ],
            },
            {
                "question": "Priorización de equipos críticos: Los asistentes…",
                "options": [
                    "No conocen los equipos críticos y no son priorizados",
                    "Conocen los equipos críticos, pero no son priorizados",
                    "Conocen los equipos críticos y velan por su priorización",
                ],
            },
            {
                "question": "Generación de avisos: Para los asistentes…",
                "options": [
                    "La mayor parte de las tareas fuera del plan matriz no tienen un aviso generado",
                    "Sólo algunas tareas se solicitan sin aviso",
                    "El ingreso de tareas sin aviso es muy excepcional",
                ],
            },
        ],
    },
    {
        "name": "Mentalidades y comportamientos",
        "items": [
            {
                "question": "Respeto por las reglas de la reunión: Los asistentes…",
                "options": [
                    "No dan importancia al cumplimiento de las reglas",
                    "Uno o más integrantes no respeta las reglas y refleja una falta de entendimiento de la importancia de la reunión",
                    "El equipo completo respeta las reglas y es reflejo de la importancia que dan a la reunión",
                ],
            },
            {
                "question": "Preparación: La preparación de la información refleja la importancia que dan los participantes a la priorización",
                "options": [
                    "La preparación necesaria es nula y se le da poca importancia en todo el equipo",
                    "Uno o más asistentes no prepara la información y no entiende su importancia",
                    "Todos aportan la información necesaria y de la manera esperada",
                ],
            },
            {
                "question": "Motivación a la priorización: El equipo entiende que el principal objetivo es la priorización",
                "options": [
                    "Se discute poco o nada de priorización",
                    "La priorización se discute parcialmente",
                    "El equipo cuestiona y analiza la priorización en cada etapa de la reunión",
                ],
            },
            {
                "question": "La comunicación: ¿La comunicación de los participantes refleja entendimiento y convicción?",
                "options": [
                    "Se observa lenguaje de desaprobación en el equipo",
                    "Uno o más integrantes muestran lenguaje de desaprobación",
                    "El equipo muestra un lenguaje positivo, colaborativo y alineado con el objetivo de la reunión",
                ],
            },
        ],
    },
]

PRIORITIZATION_PARTICIPANT_AREAS: List[str] = [
    "CONFIABILIDAD",
    "PLANIFICADOR",
    "PROGRAMADOR",
    "EJECUTOR",
    "OPERACIONES",
    "GSYS",
    "ELECTRICOS",
    "SEGURIDAD",
    "EECC 1",
    "EECC 2",
    "EECC 3",
    "EECC 4",
    "EECC 5",
]


                           
      
                           
@web_bp.get("/")
def home():
    return _render_any(["home.html", "web/home.html"])


                           
          
                           
@web_bp.get("/planning")
def planning_form():
    ex = example_data("planning")
    schema = _schema_from_example(ex)
    participant_areas = _participant_areas_from_example(ex)
    return _render_any(
        ["planning_form.html", "web/planning_form.html"],
        data=ex,
        schema=schema,
        participant_areas=participant_areas,
    )


@web_bp.post("/planning/generate")
def planning_generate_pdf():
    ex = example_data("planning")
    schema = _schema_from_example(ex)
    participant_areas = _participant_areas_from_example(ex)

    data = _parse_common_form("planning", request.form, schema, participant_areas)
    pdf_bytes = _build_pdf_bytes("planning", data)
    filename = _filename_from_data("planning", data)

    return send_file(
        io.BytesIO(pdf_bytes),
        mimetype="application/pdf",
        as_attachment=True,
        download_name=filename,
    )


                           
            
                           
@web_bp.get("/scheduling")
def scheduling_form():
    ex = example_data("scheduling")
    schema = _schema_from_example(ex)
    participant_areas = _participant_areas_from_example(ex)
    return _render_any(
        ["scheduling_form.html", "web/scheduling_form.html"],
        data=ex,
        schema=schema,
        participant_areas=participant_areas,
    )


@web_bp.post("/scheduling/generate")
def scheduling_generate_pdf():
    ex = example_data("scheduling")
    schema = _schema_from_example(ex)
    participant_areas = _participant_areas_from_example(ex)

    data = _parse_common_form("scheduling", request.form, schema, participant_areas)
    pdf_bytes = _build_pdf_bytes("scheduling", data)
    filename = _filename_from_data("scheduling", data)

    return send_file(
        io.BytesIO(pdf_bytes),
        mimetype="application/pdf",
        as_attachment=True,
        download_name=filename,
    )


                           
                  
                           
@web_bp.get("/post_maintenance")
def post_maintenance_form():
    ex = example_data("post")
    schema = _schema_from_example(ex)
    participant_areas = _participant_areas_from_example(ex)
    return _render_any(
        ["post_maintenance_form.html", "web/post_maintenance_form.html"],
        data=ex,
        schema=schema,
        participant_areas=participant_areas,
    )


@web_bp.post("/post_maintenance/generate")
def post_maintenance_generate_pdf():
    ex = example_data("post")
    schema = _schema_from_example(ex)
    participant_areas = _participant_areas_from_example(ex)

    data = _parse_common_form("post", request.form, schema, participant_areas)
    pdf_bytes = _build_pdf_bytes("post", data)
    filename = _filename_from_data("post", data)

    return send_file(
        io.BytesIO(pdf_bytes),
        mimetype="application/pdf",
        as_attachment=True,
        download_name=filename,
    )


                           
              
                           
@web_bp.get("/prioritization")
def prioritization_form():
    ex = example_data("prioritization")
    schema = PRIORITIZATION_SCHEMA
    participant_areas = PRIORITIZATION_PARTICIPANT_AREAS
    return _render_any(
        ["prioritization_form.html", "web/prioritization_form.html"],
        data=ex,
        schema=schema,
        participant_areas=participant_areas,
    )


@web_bp.post("/prioritization/generate")
def prioritization_generate_pdf():
    ex = example_data("prioritization")
    schema = PRIORITIZATION_SCHEMA
    participant_areas = PRIORITIZATION_PARTICIPANT_AREAS

    data = _parse_common_form("prioritization", request.form, schema, participant_areas)
    pdf_bytes = _build_pdf_bytes("prioritization", data)
    filename = _filename_from_data("prioritization", data)

    return send_file(
        io.BytesIO(pdf_bytes),
        mimetype="application/pdf",
        as_attachment=True,
        download_name=filename,
    )


                           
             
                           
@web_bp.get("/process_5s")
def process_5s_form():
    ex = example_data("process_5s")
    schema = _schema_from_example(ex)
    participant_areas = _participant_areas_from_example(ex)
    return _render_any(
        ["process_5s_form.html", "web/process_5s_form.html"],
        data=ex,
        schema=schema,
        participant_areas=participant_areas,
    )


@web_bp.post("/process_5s/generate")
def process_5s_generate_pdf():
    ex = example_data("process_5s")
    schema = _schema_from_example(ex)
    participant_areas = _participant_areas_from_example(ex)

    data = _parse_common_form("process_5s", request.form, schema, participant_areas)
    pdf_bytes = _build_pdf_bytes("process_5s", data)
    filename = _filename_from_data("process_5s", data)

    return send_file(
        io.BytesIO(pdf_bytes),
        mimetype="application/pdf",
        as_attachment=True,
        download_name=filename,
    )

