// static/js/date_ddmmyyyy.js
// Fecha manual DD/MM/AAAA (sin calendario).
// Uso: <input type="text" class="date-manual" placeholder="DD/MM/AAAA" ...>
// - Restringe entrada a dígitos (0-9) y separadores '/' o '-'.
// - Auto-formatea mientras se escribe: DDMMAAAA -> DD/MM/AAAA
// - Normaliza y valida (incluye validación de calendario real).

(function () {
  function onlyDigits(s) {
    return (s || "").replace(/\D/g, "");
  }

  function formatDigits(digits) {
    var d = (digits || "").slice(0, 8); // DDMMAAAA
    if (d.length <= 2) return d;
    if (d.length <= 4) return d.slice(0, 2) + "/" + d.slice(2);
    return d.slice(0, 2) + "/" + d.slice(2, 4) + "/" + d.slice(4);
  }

  function cursorPosFromDigitsCount(n) {
    // Mapea "n dígitos" -> posición en string DD/MM/AAAA
    if (n <= 2) return n;
    if (n <= 4) return n + 1; // incluye primer '/'
    return n + 2;             // incluye ambos '/'
  }

  function normalize(value) {
    var v = (value || "").trim();
    if (!v) return { value: "", valid: true };

    // Acepta entrada con cualquier separador, pero se queda con los dígitos
    var digits = onlyDigits(v);

    // Si viene incompleta, no la consideramos válida
    if (digits.length !== 8) {
      return { value: formatDigits(digits), valid: false };
    }

    v = formatDigits(digits);

    // Formato estricto
    if (!/^(0[1-9]|[12][0-9]|3[01])\/(0[1-9]|1[0-2])\/\d{4}$/.test(v)) {
      return { value: v, valid: false };
    }

    // Validación calendario real (31/02, etc.)
    var parts = v.split("/");
    var d = parseInt(parts[0], 10);
    var mo = parseInt(parts[1], 10);
    var y = parseInt(parts[2], 10);

    var dt = new Date(y, mo - 1, d);
    var ok = dt.getFullYear() === y && dt.getMonth() === (mo - 1) && dt.getDate() === d;
    return { value: v, valid: ok };
  }

  function lockToNumbers(inp) {
    // 1) Bloquea teclas no numéricas (pero permite navegación/edición)
    inp.addEventListener("keydown", function (e) {
      var k = e.key;

      // Permitir atajos comunes
      if (e.ctrlKey || e.metaKey) return;

      // Permitir teclas de control/navegación
      var allowed = [
        "Backspace", "Delete", "Tab", "Enter", "Escape",
        "ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown",
        "Home", "End"
      ];
      if (allowed.indexOf(k) >= 0) return;

      // Permitir dígitos (incluye numpad)
      if (/^\d$/.test(k)) return;

      // Permitir separadores (se normalizan a '/' automáticamente)
      if (k === "/" || k === "-") return;

      // Bloquear cualquier otro caracter (letras, símbolos, etc.)
      e.preventDefault();
    });

    // 2) Sanitiza/auto-formatea en cada input manteniendo el cursor razonablemente
    inp.addEventListener("input", function () {
      var raw = inp.value || "";
      var pos = inp.selectionStart != null ? inp.selectionStart : raw.length;

      var digitsBeforeCursor = onlyDigits(raw.slice(0, pos)).length;
      var digits = onlyDigits(raw);

      var formatted = formatDigits(digits);
      inp.value = formatted;

      var newPos = cursorPosFromDigitsCount(digitsBeforeCursor);
      // Ajuste defensivo por si el cursor queda fuera de rango
      newPos = Math.max(0, Math.min(formatted.length, newPos));
      try {
        inp.setSelectionRange(newPos, newPos);
      } catch (err) {
        // Algunos navegadores pueden fallar si el input no está enfocado
      }

      inp.setCustomValidity("");
    });
  }

  function initInput(inp) {
    if (!inp || inp.dataset.somaDateInit === "1") return;
    inp.dataset.somaDateInit = "1";

    lockToNumbers(inp);

    // Normaliza y valida al salir
    inp.addEventListener("blur", function () {
      var r = normalize(inp.value);
      inp.value = r.value;
      inp.setCustomValidity(r.valid ? "" : "Fecha inválida. Usa DD/MM/AAAA.");
    });
  }

  function initAll(root) {
    var scope = root || document;
    var inputs = scope.querySelectorAll("input.date-manual");
    inputs.forEach(initInput);
  }

  function attachFormValidation() {
    document.querySelectorAll("form").forEach(function (form) {
      if (form.dataset.somaDateForm === "1") return;
      form.dataset.somaDateForm = "1";

      form.addEventListener("submit", function (e) {
        var firstInvalid = null;
        form.querySelectorAll("input.date-manual").forEach(function (inp) {
          var r = normalize(inp.value);
          inp.value = r.value;
          if (!r.valid) {
            inp.setCustomValidity("Fecha inválida. Usa DD/MM/AAAA.");
            if (!firstInvalid) firstInvalid = inp;
          } else {
            inp.setCustomValidity("");
          }
        });

        if (firstInvalid) {
          e.preventDefault();
          firstInvalid.reportValidity();
          firstInvalid.focus();
        }
      });
    });
  }

  document.addEventListener("DOMContentLoaded", function () {
    initAll(document);
    attachFormValidation();

    // Compatibilidad con filas dinámicas existentes (compromisos):
    // se sigue llamando window.SOMA_initDateWraps(tr)
    window.SOMA_initDateWraps = initAll;
    window.SOMA_initDateInputs = initAll;
  });
})();
