                       
from __future__ import annotations

import re
from typing import Any, Dict, List

from reportlab.lib.units import cm
from reportlab.pdfgen import canvas
from reportlab.lib import colors

from app.pdf.base_layout import (
    PageStyle,
    LIGHTGRAY,
    WHITE,
    wrap_text,
    draw_box,
    draw_section_bar,
    draw_table_grid,
    draw_cell_text,
    draw_checkbox,
    draw_image_if_exists,
)


                           
                                       
                           
def build_process_5s_example_data() -> Dict[str, Any]:
    """Basado en el PDF: 'Confirmaciones 5S - 02-03-2026'."""

    def o(v: int, text: str) -> Dict[str, Any]:
        return {"value": v, "text": text}

                       
    return {
        "title": "Formulario de confirmaciones de procesos 5S",
        "codigo": "B/03/2026",
        "fecha": "02/03/2026",
        "division": "DIVISION_EJEMPLO",
        "sector": "SECTOR_EJEMPLO",
        "evaluador": "EVALUADOR_EJEMPLO",
        "supervisor": "SUPERVISOR_EJEMPLO",
        "turno": "TURNO_EJEMPLO",
        "si_gerente": "SI/GERENCIA_EJEMPLO",
        "sections": [
            {
                "name": "S1 – Seiri (Clasificación)",
                "items": [
                    {
                        "question": "¿Existen equipos innecesarios en el área?",
                        "options": [
                            o(1, "Si"),
                            o(2, "Sí, pero cuento con plan de retiro"),
                            o(3, "No existe ninguno"),
                        ],
                        "selected": 1,
                    },
                    {
                        "question": "¿Existen materiales, inventario, o insumos innecesarios en el área?",
                        "options": [
                            o(1, "Si"),
                            o(2, "Sí, pero cuento con plan de retiro"),
                            o(3, "No existe ninguno"),
                        ],
                        "selected": 2,
                    },
                    {
                        "question": "¿Existen herramientas, utensilios, objetos personales, carpetas, etc. innecesarios en el área?",
                        "options": [
                            o(1, "Si"),
                            o(2, "Sí, pero cuento con plan de retiro"),
                            o(3, "No existe ninguno"),
                        ],
                        "selected": 2,
                    },
                    {
                        "question": "¿Existen objetos innecesarios que presenten una condición insegura?",
                        "options": [
                            o(1, "Si"),
                            o(2, "Sí, pero cuento con plan de retiro"),
                            o(3, "No existe ninguno"),
                        ],
                        "selected": 0,
                    },
                ],
            },
            {
                "name": "S2 – Seiton (Orden)",
                "items": [
                    {
                        "question": "¿Existe un lugar designado para herramientas, máquinas o equipos y su cantidad óptima?",
                        "options": [
                            o(1, "No"),
                            o(2, "Sí, pero no siempre se cumple"),
                            o(3, "Si y todos los trabajadores las respetan"),
                        ],
                        "selected": 2,
                    },
                    {
                        "question": "¿Existe un lugar designado para materiales, inventario, y cuenten con gestión visual?",
                        "options": [
                            o(1, "No"),
                            o(2, "Sí, pero no presentan gestión visual"),
                            o(3, "Si y todos los trabajadores las respetan"),
                        ],
                        "selected": 0,
                    },
                    {
                        "question": "¿El área está diseñada para usar herramientas y devolverlas a su lugar fácilmente?",
                        "options": [
                            o(1, "No"),
                            o(2, "Sí, pero no siempre se cumple"),
                            o(3, "Si y todos los trabajadores las respetan"),
                        ],
                        "selected": 1,
                    },
                    {
                        "question": "¿Plan de tránsito, red húmeda y elementos de primeros auxilios están debidamente demarcados, protegidos y despejados?",
                        "options": [
                            o(1, "No"),
                            o(2, "Sí, pero no siempre se cumple"),
                            o(3, "Si y todos los trabajadores las respetan"),
                        ],
                        "selected": 3,
                    },
                ],
            },
            {
                "name": "S3 – Seiso (Limpieza)",
                "items": [
                    {
                        "question": "¿Existen contenedores de residuos cercanos a estaciones de trabajo?",
                        "options": [
                            o(1, "No"),
                            o(2, "Sí y no siempre se usan"),
                            o(3, "Si y se utilizan"),
                        ],
                        "selected": 3,
                    },
                    {
                        "question": "¿Existe una clasificación de residuos incluyendo reciclaje?",
                        "options": [
                            o(1, "No"),
                            o(2, "Sí y no siempre se usan"),
                            o(3, "Si y se cumple"),
                        ],
                        "selected": 2,
                    },
                    {
                        "question": "¿Existen fuentes de suciedad o contaminación en el área?",
                        "options": [
                            o(1, "Si"),
                            o(2, "Sí, pero no existe un plan de eliminación"),
                            o(3, "No existe ninguna"),
                        ],
                        "selected": 0,
                    },
                    {
                        "question": "¿Existe una segregación de desechos que evite comprometer la salud de los trabajadores(as)?",
                        "options": [
                            o(1, "No"),
                            o(2, "Sí y no siempre se cumple"),
                            o(3, "Si y se cumple"),
                        ],
                        "selected": 2,
                    },
                ],
            },
            {
                "name": "S4 – Seiketsu (Estandarización)",
                "items": [
                    {
                        "question": "¿El área cuenta con un plan de retiro de desechos en la operación y/o mantenimiento?",
                        "options": [
                            o(1, "No"),
                            o(2, "Sí y no siempre se cumple"),
                            o(3, "Si y se cumple"),
                        ],
                        "selected": 1,
                    },
                    {
                        "question": "¿Existen estándares de limpieza en el área?",
                        "options": [
                            o(1, "No"),
                            o(2, "Sí y no siempre se cumple"),
                            o(3, "Si y se cumple"),
                        ],
                        "selected": 2,
                    },
                    {
                        "question": "¿Existe un estándar de orden y layout del área?",
                        "options": [
                            o(1, "No"),
                            o(2, "Sí y no siempre se cumple"),
                            o(3, "Si y se cumple"),
                        ],
                        "selected": 2,
                    },
                    {
                        "question": "¿Se han actualizado los estándares respecto a las oportunidades de mejora?",
                        "options": [
                            o(1, "No"),
                            o(2, "Sí, pero no se utilizan"),
                            o(3, "Si y se utilizan"),
                        ],
                        "selected": 3,
                    },
                ],
            },
            {
                "name": "S5 – Shitsuke (Disciplina)",
                "items": [
                    {
                        "question": "¿Se realizan CdP por los líderes de forma periódica?",
                        "options": [
                            o(1, "No"),
                            o(2, "Sí, pero no se abordan acciones de mejora"),
                            o(3, "Si, y se abordan acciones de mejora"),
                        ],
                        "selected": 3,
                    },
                    {
                        "question": "¿Está actualizado el tablero de control 5S?",
                        "options": [
                            o(1, "No"),
                            o(2, "Sí, pero no se abordan acciones de mejora"),
                            o(3, "Si, y se abordan acciones de mejora"),
                        ],
                        "selected": 2,
                    },
                    {
                        "question": "¿Existe una reunión formal donde se pueda hacer un seguimiento y plantear oportunidades de mejora?",
                        "options": [
                            o(1, "No"),
                            o(2, "Sí y no siempre se realizan"),
                            o(3, "Si, se llevan a cabo sistemáticamente y hay una gran participación del equipo"),
                        ],
                        "selected": 0,
                    },
                    {
                        "question": "¿Se integra el método 5S en la rutina diaria?",
                        "options": [
                            o(1, "No, solo cuando hay supervisión"),
                            o(2, "Sí, pero no siempre"),
                            o(3, "Si y de forma autónoma"),
                        ],
                        "selected": 0,
                    },
                ],
            },
        ],
                                                          
        "participants": [],
        "observers": [],
        "feedback": {"fortalezas": "", "oportunidades": "", "plan": ""},
        "commitments": [],
    }


                           
              
                           
def _as_int(v: Any, default: int = 0) -> int:
    try:
        return int(v)
    except Exception:
        return default


def _fmt_fecha(s: str) -> str:
    """
    Acepta:
      - YYYY-MM-DD (input type=date)
      - DD/MM/YYYY
    Devuelve algo legible para el PDF.
    """
    s = (s or "").strip()
    if re.match(r"^\d{4}-\d{2}-\d{2}$", s):
        y, m, d = s.split("-")
        return f"{d}/{m}/{y}"
    return s


def _draw_header_5s(
    c: canvas.Canvas,
    style: PageStyle,
    data: Dict[str, Any],
    base_dir: str,
    *,
    show_info: bool,
) -> float:
    """Dibuja header (logos + título + código) y opcionalmente el bloque de datos."""
    pw, ph = style.pagesize
    x0 = style.margin_left
    y_top = ph - style.margin_top

                                                                                               
    img_dir = f"{base_dir}/app/static/img"
    codelco = f"{img_dir}/codelco.png"
    doa = f"{img_dir}/doa.png"

           
    draw_image_if_exists(c, codelco, x0, y_top - 1.05 * cm, 3.3 * cm, 0.95 * cm)
    draw_image_if_exists(c, doa, x0 + 3.6 * cm, y_top - 1.05 * cm, 3.3 * cm, 0.95 * cm)

            
    title = str(data.get("title") or "Formulario de confirmaciones de procesos 5S")

    # TÍTULO: centrado y con ajuste de línea (evita que se sobreponga con otros textos)
    title_x_left = x0 + 7.2 * cm
    title_x_right = pw - style.margin_right
    avail_w = max(1.0, title_x_right - title_x_left)

    font_sizes = [13, 12, 11, 10]
    title_lines: List[str] = []
    chosen_size = font_sizes[-1]
    for fs in font_sizes:
        wrapped = wrap_text(title, style.font_bold, fs, avail_w)
        chosen_size = fs
        title_lines = wrapped
        if len(wrapped) <= 2:
            break

    if len(title_lines) > 2:
        title_lines = title_lines[:2]
        if title_lines[-1] and not title_lines[-1].endswith("…"):
            s = title_lines[-1].rstrip()
            title_lines[-1] = (s[:-1] + "…") if len(s) > 1 else (s + "…")

    c.setFont(style.font_bold, chosen_size)
    center_x = title_x_left + avail_w / 2.0
    y_title = y_top - 0.95 * cm
    line_step = chosen_size * 1.25  # puntos

    for i, ln in enumerate(title_lines):
        c.drawCentredString(center_x, y_title - i * line_step, ln)

    # FECHA: se muestra una sola vez, bajo el título
    fecha = _fmt_fecha(str(data.get("fecha") or ""))
    content_bottom = y_title - (len(title_lines) - 1) * line_step
    if fecha:
        c.setFont(style.font, 9)
        last_y = y_title - (len(title_lines) - 1) * line_step
        # 12pt bajo el último renglón del título (evita solape con 2 líneas)
        date_y = min(y_top - 1.45 * cm, last_y - 12)
        c.drawRightString(pw - style.margin_right, date_y, f"Fecha: {fecha}")
        content_bottom = min(content_bottom, date_y)

    # Línea separadora bajo el header
    sep_y = min(y_top - 2.05 * cm, content_bottom - 0.35 * cm)
    c.setStrokeColor(colors.lightgrey)
    c.setLineWidth(1)
    c.line(style.margin_left, sep_y, pw - style.margin_right, sep_y)

    y = sep_y - 0.40 * cm

    if not show_info:
        return y

                                            
    w = pw - style.margin_left - style.margin_right
    col_w = w / 3.0
    row_h = 0.95 * cm

    div = str(data.get("division") or "")
    sec = str(data.get("sector") or "")
    eva = str(data.get("evaluador") or "")
    sup = str(data.get("supervisor") or "")
    tur = str(data.get("turno") or "")
    sig = str(data.get("si_gerente") or "")

    labels_1 = [("DIVISIÓN", div), ("SECTOR", sec), ("EVALUADOR", eva)]
    labels_2 = [("SUPERVISOR", sup), ("TURNO", tur), ("SI/ GERENTE", sig)]

    def cell(ix: int, iy: int, label: str, value: str):
        cx = style.margin_left + ix * col_w
        cy = y - (iy + 1) * row_h
        draw_box(c, cx, cy, col_w, row_h, fill_color=WHITE, stroke=1)
        c.setFont(style.font_bold, 8.5)
        c.drawString(cx + 0.20 * cm, cy + row_h - 0.35 * cm, f"{label}:")
        draw_cell_text(
            c,
            cx,
            cy,
            col_w,
            row_h - 0.1 * cm,
            value,
            font_name=style.font,
            font_size=9,
            padding=0.20 * cm,
            valign="bottom",
        )

    for i, (lab, val) in enumerate(labels_1):
        cell(i, 0, lab, val)
    for i, (lab, val) in enumerate(labels_2):
        cell(i, 1, lab, val)

    return y - 2 * row_h - 0.45 * cm


def _measure_row_height(
    style: PageStyle,
    q: str,
    opts: List[str],
    col_w_question: float,
    col_w_opt: float,
) -> float:
    """Altura dinámica por wrapping (pregunta + opciones)."""
    pad = 0.18 * cm
    q_font = 8.7
    opt_font = 7.6
    q_lead = q_font * 1.25
    o_lead = opt_font * 1.25

    q_lines = wrap_text(q, style.font, q_font, max(1.0, col_w_question - 2 * pad))
    o_lines_max = 1
    for t in opts:
        cb = 0.32 * cm
        gap = 0.10 * cm
        max_w = max(1.0, col_w_opt - cb - gap - 3 * pad)
        lines = wrap_text(t, style.font, opt_font, max_w)
        o_lines_max = max(o_lines_max, len(lines))

    h_q = len(q_lines) * q_lead + 2 * pad
    h_o = o_lines_max * o_lead + 2 * pad
    return max(1.10 * cm, h_q, h_o)


def _draw_table_header_5s(
    c: canvas.Canvas,
    style: PageStyle,
    x: float,
    y_top: float,
    col_ws: List[float],
) -> float:
    """Fila header para N°, Item, 1/2/3/N-A y Puntuación."""
    row_h = 0.80 * cm
    y = y_top - row_h

    cx = x
    for w in col_ws:
        draw_box(c, cx, y, w, row_h, fill_color=LIGHTGRAY, stroke=1)
        cx += w

    headers = ["N°", "ITEM EVALUADO", "1 (Malo)", "2 (Regular)", "3 (Bueno)", "N/A", "Puntuación"]
    cx = x
    for i, htxt in enumerate(headers):
        draw_cell_text(
            c,
            cx,
            y,
            col_ws[i],
            row_h,
            htxt,
            font_name=style.font_bold,
            font_size=9,
            padding=0.18 * cm,
            valign="middle",
        )
        cx += col_ws[i]

    return y - 0.10 * cm


def render_process_5s_pdf(c: canvas.Canvas, data: Dict[str, Any], base_dir: str) -> None:
    style = PageStyle()
    pw, _ph = style.pagesize

    x0 = style.margin_left
    w = pw - style.margin_left - style.margin_right

    col_ws = [
        0.70 * cm,
        6.90 * cm,
        2.20 * cm,
        2.20 * cm,
        2.20 * cm,
        2.20 * cm,
        1.60 * cm,
    ]

    def new_page(*, show_info: bool) -> float:
        c.showPage()
        return _draw_header_5s(c, style, data, base_dir, show_info=show_info)

    y = _draw_header_5s(c, style, data, base_dir, show_info=True)

    total = 0
    for sec in (data.get("sections") or []):
        sec_name = str(sec.get("name") or "")
        items = list(sec.get("items") or [])

        min_needed = 0.60 * cm + 0.80 * cm + 1.20 * cm
        if y - min_needed < style.margin_bottom:
            y = new_page(show_info=False)

        bar_h = 0.55 * cm
        draw_section_bar(c, x0, y - bar_h, w, bar_h, sec_name)
        y = y - bar_h - 0.15 * cm

        y = _draw_table_header_5s(c, style, x0, y, col_ws)

        subtotal = 0
        for idx, it in enumerate(items, start=1):
            q = str(it.get("question") or "")
            opts = it.get("options") or []
            opt_texts = [str(o.get("text") or "") for o in opts[:3]]

            sel = _as_int(it.get("selected"), 0)
            if sel not in (0, 1, 2, 3):
                sel = 0

            row_h = _measure_row_height(style, q, opt_texts, col_ws[1], col_ws[2])
            if y - row_h < style.margin_bottom:
                y = new_page(show_info=False)
                draw_section_bar(c, x0, y - bar_h, w, bar_h, sec_name)
                y = y - bar_h - 0.15 * cm
                y = _draw_table_header_5s(c, style, x0, y, col_ws)

            y_row = y - row_h

            draw_table_grid(c, x0, y_row, col_ws, [row_h], stroke=1)

            draw_cell_text(
                c, x0, y_row, col_ws[0], row_h, str(idx),
                font_name=style.font_bold, font_size=9, padding=0.18 * cm, valign="middle",
            )

            draw_cell_text(
                c, x0 + col_ws[0], y_row, col_ws[1], row_h, q,
                font_name=style.font, font_size=8.7, padding=0.18 * cm, valign="middle",
            )

            for j in range(3):
                cell_x = x0 + col_ws[0] + col_ws[1] + j * col_ws[2]
                txt = opt_texts[j] if j < len(opt_texts) else ""

                cb = 0.32 * cm
                cb_x = cell_x + 0.18 * cm
                cb_y = y_row + row_h - cb - 0.22 * cm
                draw_checkbox(c, cb_x, cb_y, size=cb, checked=(sel == (j + 1)))

                left = 0.18 * cm + cb + 0.10 * cm
                draw_cell_text(
                    c,
                    cell_x + left,
                    y_row,
                    col_ws[2] - left,
                    row_h,
                    txt,
                    font_name=style.font,
                    font_size=7.6,
                    padding=0.18 * cm,
                    valign="top",
                )

            cell_x_na = x0 + col_ws[0] + col_ws[1] + 3 * col_ws[2]
            cb = 0.32 * cm
            cb_x = cell_x_na + 0.18 * cm
            cb_y = y_row + row_h - cb - 0.22 * cm
            draw_checkbox(c, cb_x, cb_y, size=cb, checked=(sel == 0))

            pts = sel
            draw_cell_text(
                c, x0 + sum(col_ws[:-1]), y_row, col_ws[-1], row_h, str(pts),
                font_name=style.font_bold, font_size=10, padding=0.18 * cm, valign="middle",
            )

            subtotal += pts
            y = y_row

        sub_h = 0.75 * cm
        if y - sub_h < style.margin_bottom:
            y = new_page(show_info=False)
            draw_section_bar(c, x0, y - bar_h, w, bar_h, sec_name)
            y = y - bar_h - 0.15 * cm
            y = _draw_table_header_5s(c, style, x0, y, col_ws)

        y_sub = y - sub_h
        draw_table_grid(c, x0, y_sub, col_ws, [sub_h], stroke=1)

        draw_cell_text(
            c,
            x0 + col_ws[0] + col_ws[1] + 3 * col_ws[2],
            y_sub,
            col_ws[5],
            sub_h,
            "Sub-total",
            font_name=style.font_bold,
            font_size=9,
            padding=0.18 * cm,
            valign="middle",
        )
        draw_cell_text(
            c,
            x0 + sum(col_ws[:-1]),
            y_sub,
            col_ws[-1],
            sub_h,
            str(subtotal),
            font_name=style.font_bold,
            font_size=10,
            padding=0.18 * cm,
            valign="middle",
        )

        y = y_sub - 0.25 * cm
        total += subtotal

    total_h = 0.85 * cm
    if y - total_h < style.margin_bottom:
        y = new_page(show_info=False)

    y_tot = y - total_h
    draw_box(c, x0, y_tot, sum(col_ws), total_h, fill_color=LIGHTGRAY, stroke=1)
    draw_table_grid(c, x0, y_tot, col_ws, [total_h], stroke=1)

    draw_cell_text(
        c,
        x0 + col_ws[0] + col_ws[1] + 2 * col_ws[2],
        y_tot,
        col_ws[2] + col_ws[3] + col_ws[4],
        total_h,
        "Puntaje total",
        font_name=style.font_bold,
        font_size=10,
        padding=0.18 * cm,
        valign="middle",
    )
    draw_cell_text(
        c,
        x0 + sum(col_ws[:-1]),
        y_tot,
        col_ws[-1],
        total_h,
        str(total),
        font_name=style.font_bold,
        font_size=12,
        padding=0.18 * cm,
        valign="middle",
    )

