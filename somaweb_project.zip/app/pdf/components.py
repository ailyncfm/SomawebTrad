# app/pdf/components.py
from __future__ import annotations

import os
from typing import Dict, Any, List, Optional

from reportlab.lib import colors
from reportlab.lib.units import cm
from reportlab.pdfbase import pdfmetrics

from app.pdf.base_layout import PageStyle, draw_section_bar



def _set_stroke(c, stroke_color=colors.black, line_width: float = 1.0):
    c.setStrokeColor(stroke_color)
    c.setLineWidth(line_width)


def draw_box(
    c,
    x: float,
    y: float,
    w: float,
    h: float,
    *,
    fill_color=None,
    stroke: int = 1,
    stroke_color=colors.black,
    line_width: float = 1.0,
):
    c.saveState()
    _set_stroke(c, stroke_color=stroke_color, line_width=line_width)
    if fill_color is None:
        c.setFillColor(colors.white)
        c.rect(x, y, w, h, stroke=stroke, fill=0)
    else:
        c.setFillColor(fill_color)
        c.rect(x, y, w, h, stroke=stroke, fill=1)
    c.restoreState()


def draw_image_if_exists(c, path: str, x: float, y: float, w: float, h: float):
    if not path or not os.path.isfile(path):
        return
    c.saveState()
    c.drawImage(path, x, y, width=w, height=h, preserveAspectRatio=True, mask="auto")
    c.restoreState()


def _wrap_text_lines(text: str, font_name: str, font_size: float, max_width: float) -> List[str]:
    text = (text or "").strip()
    if not text:
        return [""]

    def w(s: str) -> float:
        return pdfmetrics.stringWidth(s, font_name, font_size)

    words = text.split()
    lines: List[str] = []
    cur = ""

    for word in words:
        tentative = (cur + " " + word).strip() if cur else word
        if w(tentative) <= max_width:
            cur = tentative
            continue

        if cur:
            lines.append(cur)
            cur = ""

        if w(word) <= max_width:
            cur = word
            continue

        chunk = ""
        for ch in word:
            t2 = chunk + ch
            if w(t2) <= max_width:
                chunk = t2
            else:
                if chunk:
                    lines.append(chunk)
                chunk = ch
        if chunk:
            cur = chunk

    if cur:
        lines.append(cur)

    return lines


def _draw_wrapped_text_block(
    c,
    x: float,
    y: float,
    w: float,
    h: float,
    lines: List[str],
    *,
    font_name: str,
    font_size: float,
    leading: float,
    align: str = "left",
    valign: str = "top",
    pad: float = 0.18 * cm,
):
    c.saveState()
    c.setFont(font_name, font_size)

    block_h = max(1, len(lines)) * leading

    if valign == "middle":
        y_top = y + (h + block_h) / 2.0
    else:
        y_top = y + h - pad

    y_cursor = y_top - font_size

    for line in lines:
        if align == "center":
            lw = pdfmetrics.stringWidth(line, font_name, font_size)
            x_line = x + pad + max(0.0, (w - 2 * pad - lw) / 2.0)
        else:
            x_line = x + pad

        c.drawString(x_line, y_cursor, line)
        y_cursor -= leading

        if y_cursor < (y + pad - font_size):
            break

    c.restoreState()


# =========================
# Bloques del PDF (UI)
# =========================
def draw_header(c, style: PageStyle, title: str, fecha: str, hora: str, logo_dir: str) -> float:
    pw, ph = style.pagesize
    x0 = style.margin_left
    y_top = ph - style.margin_top

    codelco = os.path.join(logo_dir, "codelco.png")
    doa = os.path.join(logo_dir, "doa.png")

    draw_image_if_exists(c, codelco, x0, y_top - 1.05 * cm, 3.3 * cm, 0.95 * cm)
    draw_image_if_exists(c, doa, x0 + 3.6 * cm, y_top - 1.05 * cm, 3.3 * cm, 0.95 * cm)

    # TÍTULO: centrado y con ajuste de línea para evitar que se "corte" en PDF
    title_x_left = x0 + 7.2 * cm
    title_x_right = pw - style.margin_right
    avail_w = max(1.0, title_x_right - title_x_left)

    font_sizes = [13, 12, 11, 10]
    title_lines = []
    chosen_size = font_sizes[-1]
    for fs in font_sizes:
        wrapped = _wrap_text_lines(title, style.font_bold, fs, avail_w)
        chosen_size = fs
        title_lines = wrapped
        if len(wrapped) <= 2:
            break

    if len(title_lines) > 2:
        title_lines = title_lines[:2]
        if title_lines[-1] and not title_lines[-1].endswith("…"):
            s = title_lines[-1].rstrip()
            title_lines[-1] = (s[:-1] + "…") if len(s) > 1 else (s + "…")

    c.setFont(style.font_bold, chosen_size)
    center_x = title_x_left + avail_w / 2.0
    y_title = y_top - 0.95 * cm
    line_step = chosen_size * 1.25  # puntos

    for i, ln in enumerate(title_lines):
        c.drawCentredString(center_x, y_title - i * line_step, ln)

    # Si el título ocupa 2 líneas, bajamos el bloque Fecha/Hora para evitar solapes
    extra_down = max(0.0, (len(title_lines) - 1) * line_step)

    box_h = 0.85 * cm
    y = y_top - 2.0 * cm - extra_down - 0.15 * cm

    c.setFont(style.font_bold, 9)
    c.drawString(x0, y + 0.25 * cm, "Fecha")
    draw_box(c, x0 + 1.2 * cm, y, 3.2 * cm, box_h)
    c.setFont(style.font, 9)
    c.drawString(x0 + 1.35 * cm, y + 0.25 * cm, fecha)

    c.setFont(style.font_bold, 9)
    c.drawString(x0 + 4.8 * cm, y + 0.25 * cm, "Hora")
    draw_box(c, x0 + 5.7 * cm, y, 2.4 * cm, box_h)
    c.setFont(style.font, 9)
    c.drawString(x0 + 5.85 * cm, y + 0.25 * cm, hora)

    return y - 0.6 * cm


def draw_observer_block(c, x: float, y_top: float, w: float, observer: Dict[str, Any], idx: int) -> float:
    style = PageStyle()
    title_h = 0.55 * cm
    row_h = 0.75 * cm
    pad = 0.15 * cm

    c.setFont(style.font_bold, 10)
    c.drawString(x, y_top - 0.35 * cm, f"Observador {idx}")
    y_top -= title_h

    col1_w = w * 0.52
    col2_w = w - col1_w

    rows = [
        ("Id", "id", "Nombre", "nombre"),
        ("Gerencia", "gerencia", "Superintendencia", "superintendencia"),
        ("SAP", "sap", "E-mail", "email"),
        ("Denominación posición", "posicion", "", ""),
    ]

    for (l1, k1, l2, k2) in rows:
        y = y_top - row_h

        c.setFont(style.font, 9)
        c.drawString(x + pad, y + 0.25 * cm, l1)
        draw_box(c, x + 3.5 * cm, y + 0.12 * cm, col1_w - 3.7 * cm, row_h - 0.22 * cm)
        val1 = str(observer.get(k1, "") or "")
        c.drawString(x + 3.65 * cm, y + 0.25 * cm, val1)

        if l2:
            c.drawString(x + col1_w + pad, y + 0.25 * cm, l2)
            draw_box(c, x + col1_w + 3.8 * cm, y + 0.12 * cm, col2_w - 4.0 * cm, row_h - 0.22 * cm)
            val2 = str(observer.get(k2, "") or "")
            c.drawString(x + col1_w + 3.95 * cm, y + 0.25 * cm, val2)

        y_top = y

    return y_top - 0.25 * cm


def draw_area_row(c, x: float, y_top: float, w: float, area: str) -> float:
    style = PageStyle()
    row_h = 0.75 * cm
    pad = 0.15 * cm

    y = y_top - row_h
    c.setFont(style.font, 9)
    c.drawString(x + pad, y + 0.25 * cm, "Área")
    draw_box(c, x + 1.0 * cm, y + 0.12 * cm, w - 1.0 * cm, row_h - 0.22 * cm)
    c.drawString(x + 1.15 * cm, y + 0.25 * cm, area or "")
    return y - 0.35 * cm


def draw_scale_row(c, x: float, y_top: float, w: float) -> float:
    style = PageStyle()
    row_h = 0.85 * cm
    q_w = w * 0.40
    opt_w = (w - q_w) / 3.0

    y = y_top - row_h

    draw_box(c, x, y, q_w, row_h, fill_color=colors.white, stroke=1)
    for i in range(3):
        draw_box(c, x + q_w + i * opt_w, y, opt_w, row_h, fill_color=colors.white, stroke=1)

    c.setFont(style.font_bold, 10)
    c.drawString(x + 0.35 * cm, y + 0.30 * cm, "Aspecto / Pregunta")

    for i, lab in enumerate(["1", "2", "3"]):
        cell_x = x + q_w + i * opt_w
        lw = pdfmetrics.stringWidth(lab, style.font_bold, 10)
        c.drawString(cell_x + (opt_w - lw) / 2.0, y + 0.30 * cm, lab)

    return y - 0.2 * cm


# =========================
# EVALUATION ROW (wrap + alto dinámico)
# =========================
def measure_eval_item_row_height(
    c,
    total_w: float,
    question: str,
    options: List[str],
    *,
    min_h: float = 1.55 * cm,
    q_ratio: float = 0.40,
    q_font_size: float = 9.0,
    opt_font_size: float = 8.5,
    leading_mult: float = 1.15,
) -> float:
    style = PageStyle()
    q_w = total_w * q_ratio
    opt_w = (total_w - q_w) / 3.0

    pad = 0.18 * cm
    checkbox = 0.38 * cm
    gap = 0.10 * cm

    q_lines = _wrap_text_lines(question, style.font_bold, q_font_size, max(1.0, q_w - 2 * pad))
    q_leading = q_font_size * leading_mult
    q_block_h = max(1, len(q_lines)) * q_leading
    q_h = pad + q_block_h + pad

    opt_leading = opt_font_size * leading_mult
    opt_max_h = 0.0
    for opt in (options or [])[:3]:
        avail = max(1.0, opt_w - (2 * pad) - (checkbox + gap))
        lines = _wrap_text_lines(opt, style.font, opt_font_size, avail)
        text_h = max(1, len(lines)) * opt_leading
        h = pad + checkbox + gap + text_h + pad
        opt_max_h = max(opt_max_h, h)

    return max(min_h, q_h, opt_max_h)


def draw_eval_item_row(
    c,
    x: float,
    y_top: float,
    w: float,
    *,
    question: str,
    options: List[str],
    selected: int,
    row_h: Optional[float] = None,
) -> float:
    style = PageStyle()
    q_ratio = 0.40
    q_w = w * q_ratio
    opt_w = (w - q_w) / 3.0

    if row_h is None:
        row_h = measure_eval_item_row_height(c, w, question, options)

    y = y_top - row_h

    pad = 0.18 * cm
    checkbox = 0.38 * cm
    gap = 0.10 * cm
    q_font_size = 9.0
    opt_font_size = 8.5
    leading_mult = 1.15
    q_leading = q_font_size * leading_mult
    opt_leading = opt_font_size * leading_mult

    draw_box(c, x, y, q_w, row_h, fill_color=None, stroke=1)
    for i in range(3):
        draw_box(c, x + q_w + i * opt_w, y, opt_w, row_h, fill_color=None, stroke=1)

    q_lines = _wrap_text_lines(question, style.font_bold, q_font_size, max(1.0, q_w - 2 * pad))
    _draw_wrapped_text_block(
        c, x, y, q_w, row_h, q_lines,
        font_name=style.font_bold, font_size=q_font_size, leading=q_leading,
        align="left", valign="top", pad=pad
    )

    for i, opt in enumerate((options or [])[:3]):
        cell_x = x + q_w + i * opt_w

        cb_x = cell_x + pad
        cb_y = y + row_h - pad - checkbox
        draw_box(c, cb_x, cb_y, checkbox, checkbox, fill_color=None, stroke=1)

        if (i + 1) == int(selected):
            c.saveState()
            _set_stroke(c, line_width=1.0)
            c.line(cb_x + 0.07 * cm, cb_y + 0.18 * cm, cb_x + 0.16 * cm, cb_y + 0.07 * cm)
            c.line(cb_x + 0.16 * cm, cb_y + 0.07 * cm, cb_x + 0.32 * cm, cb_y + 0.30 * cm)
            c.restoreState()

        avail_w = max(1.0, opt_w - (2 * pad) - (checkbox + gap))
        lines = _wrap_text_lines(opt, style.font, opt_font_size, avail_w)

        text_x = cb_x + checkbox + gap
        text_y = y + pad
        text_h = (row_h - (pad * 2) - (checkbox + gap))
        if text_h < (0.6 * cm):
            text_h = row_h - (pad * 2)

        _draw_wrapped_text_block(
            c, text_x, text_y, avail_w, text_h, lines,
            font_name=style.font, font_size=opt_font_size, leading=opt_leading,
            align="center", valign="middle", pad=0.0
        )

    return y


# =========================
# FEEDBACK (wrap + alto dinámico)
# =========================
def measure_feedback_block_height(w: float, fortalezas: str, oportunidades: str, plan: str) -> float:
    style = PageStyle()
    left_w = w * 0.78
    label_w = left_w * 0.33
    value_w = left_w - label_w

    base_row = 0.95 * cm
    pad = 0.18 * cm

    f_lines = _wrap_text_lines(fortalezas, style.font, 9.0, max(1.0, value_w - 2 * pad))
    o_lines = _wrap_text_lines(oportunidades, style.font, 9.0, max(1.0, value_w - 2 * pad))
    f_h = max(base_row, (len(f_lines) * 10.0) + 2 * pad)
    o_h = max(base_row, (len(o_lines) * 10.0) + 2 * pad)

    plan_lines = _wrap_text_lines(plan, style.font, 9.0, max(1.0, value_w - 2 * pad))
    plan_leading = 9.0 * 1.15
    plan_h = max(3.1 * cm, (len(plan_lines) * plan_leading) + 2 * pad)

    bar_h = 0.6 * cm
    return bar_h + f_h + o_h + plan_h + 0.25 * cm


def draw_feedback_block(
    c,
    x: float,
    y_top: float,
    w: float,
    *,
    fortalezas: str,
    oportunidades: str,
    plan: str,
    suma: float,   # <- ahora lo tratamos como puntaje (float) para imprimir 1 decimal
    nota: float,
) -> float:
    style = PageStyle()

    bar_h = 0.6 * cm
    y_bar = y_top - bar_h
    draw_section_bar(c, x, y_bar, w, bar_h, "FEEDBACK")
    y_top = y_bar - 0.18 * cm

    left_w = w * 0.78
    right_w = w - left_w
    label_w = left_w * 0.33
    value_w = left_w - label_w

    base_row = 0.95 * cm
    pad = 0.18 * cm

    f_lines = _wrap_text_lines(fortalezas, style.font, 9.0, max(1.0, value_w - 2 * pad))
    o_lines = _wrap_text_lines(oportunidades, style.font, 9.0, max(1.0, value_w - 2 * pad))
    f_h = max(base_row, (len(f_lines) * (9.0 * 1.15)) + 2 * pad)
    o_h = max(base_row, (len(o_lines) * (9.0 * 1.15)) + 2 * pad)

    plan_lines = _wrap_text_lines(plan, style.font, 9.0, max(1.0, value_w - 2 * pad))
    plan_leading = 9.0 * 1.15
    plan_h = max(3.1 * cm, (len(plan_lines) * plan_leading) + 2 * pad)

    # Fortalezas
    y = y_top - f_h
    draw_box(c, x, y, label_w, f_h, fill_color=colors.lightgrey, stroke=1)
    draw_box(c, x + label_w, y, value_w, f_h, fill_color=colors.white, stroke=1)
    c.setFont(style.font_bold, 9)
    c.drawString(x + 0.2 * cm, y + f_h - 0.55 * cm, "Fortalezas de la reunión:")
    _draw_wrapped_text_block(
        c, x + label_w, y, value_w, f_h, f_lines,
        font_name=style.font, font_size=9.0, leading=9.0 * 1.15,
        align="left", valign="middle", pad=pad
    )

    # Score box a la derecha
    score_x = x + left_w
    score_top = y_top
    score_cell_h = base_row

    # Suma del puntaje
    y_score1 = score_top - score_cell_h
    draw_box(c, score_x, y_score1, right_w, score_cell_h, fill_color=colors.lightgrey, stroke=1)
    c.setFont(style.font_bold, 9)
    c.drawString(score_x + 0.2 * cm, y_score1 + 0.28 * cm, "Suma del puntaje")

    y_score1v = y_score1 - score_cell_h
    draw_box(c, score_x, y_score1v, right_w, score_cell_h, fill_color=colors.white, stroke=1)
    c.setFont(style.font, 10)
    c.drawString(score_x + 0.25 * cm, y_score1v + 0.28 * cm, f"{float(suma):.1f}")  # <- 1 decimal

    # Nota
    y_score2 = y_score1v - score_cell_h
    draw_box(c, score_x, y_score2, right_w, score_cell_h, fill_color=colors.lightgrey, stroke=1)
    c.setFont(style.font_bold, 9)
    c.drawString(score_x + 0.2 * cm, y_score2 + 0.28 * cm, "Nota")

    y_score2v = y_score2 - score_cell_h
    draw_box(c, score_x, y_score2v, right_w, score_cell_h, fill_color=colors.white, stroke=1)
    c.setFont(style.font, 10)
    c.drawString(score_x + 0.25 * cm, y_score2v + 0.28 * cm, f"{nota:.1f}")

    # Oportunidades
    y2 = y - o_h
    draw_box(c, x, y2, label_w, o_h, fill_color=colors.lightgrey, stroke=1)
    draw_box(c, x + label_w, y2, value_w, o_h, fill_color=colors.white, stroke=1)
    c.setFont(style.font_bold, 9)
    c.drawString(x + 0.2 * cm, y2 + o_h - 0.55 * cm, "Oportunidades de la reunión:")
    _draw_wrapped_text_block(
        c, x + label_w, y2, value_w, o_h, o_lines,
        font_name=style.font, font_size=9.0, leading=9.0 * 1.15,
        align="left", valign="middle", pad=pad
    )

    # Plan
    y3 = y2 - plan_h
    draw_box(c, x, y3, label_w, plan_h, fill_color=colors.lightgrey, stroke=1)
    draw_box(c, x + label_w, y3, value_w, plan_h, fill_color=colors.white, stroke=1)
    c.setFont(style.font_bold, 9)
    c.drawString(x + 0.2 * cm, y3 + plan_h - 0.55 * cm, "Plan")
    _draw_wrapped_text_block(
        c, x + label_w, y3, value_w, plan_h, plan_lines,
        font_name=style.font, font_size=9.0, leading=plan_leading,
        align="left", valign="top", pad=pad
    )

    return y3 - 0.35 * cm


# =========================
# Tablas finales
# =========================
def draw_commitments_table(c, x: float, y_top: float, w: float, commitments: List[Dict[str, Any]]) -> float:
    style = PageStyle()
    c.setFont(style.font_bold, 11)
    c.drawString(x, y_top, "Compromisos")
    y_top -= 0.55 * cm

    header_h = 0.9 * cm
    row_h = 1.05 * cm

    cols = [
        ("Acción propuesta", 0.36),
        ("Responsable", 0.16),
        ("Fecha\nCompromiso", 0.12),
        ("Estado de la\nacción", 0.16),
        ("Evidencia de\ncierre", 0.20),
    ]
    xs = [x]
    for _, r in cols:
        xs.append(xs[-1] + w * r)

    y = y_top - header_h
    for i, (name, _) in enumerate(cols):
        draw_box(c, xs[i], y, xs[i + 1] - xs[i], header_h, fill_color=colors.darkgrey, stroke=1)
        c.setFillColor(colors.white)
        c.setFont(style.font_bold, 9)
        _draw_wrapped_text_block(
            c, xs[i], y, xs[i + 1] - xs[i], header_h,
            _wrap_text_lines(name, style.font_bold, 9, (xs[i + 1] - xs[i]) - 0.3 * cm),
            font_name=style.font_bold, font_size=9, leading=10,
            align="center", valign="middle", pad=0.0
        )
        c.setFillColor(colors.black)

    y_top = y

    for row in commitments:
        y = y_top - row_h
        vals = [
            str(row.get("accion", "") or ""),
            str(row.get("responsable", "") or ""),
            str(row.get("fecha", "") or ""),
            str(row.get("estado", "") or ""),
            str(row.get("evidencia", "") or ""),
        ]
        for i, v in enumerate(vals):
            draw_box(c, xs[i], y, xs[i + 1] - xs[i], row_h, fill_color=colors.white, stroke=1)
            _draw_wrapped_text_block(
                c, xs[i], y, xs[i + 1] - xs[i], row_h,
                _wrap_text_lines(v, style.font, 9, (xs[i + 1] - xs[i]) - 0.35 * cm),
                font_name=style.font, font_size=9, leading=10,
                align="left", valign="middle", pad=0.18 * cm
            )
        y_top = y

    return y_top - 0.45 * cm


def draw_participants_table(c, x: float, y_top: float, w: float, participants: List[Dict[str, Any]]) -> float:
    style = PageStyle()
    c.setFont(style.font_bold, 11)
    c.drawString(x, y_top, "Participantes")
    y_top -= 0.55 * cm

    header_h = 0.9 * cm
    row_h = 0.9 * cm

    cols = [
        ("Área", 0.28),
        ("Responsable", 0.44),
        ("Asistió? (Si)", 0.14),
        ("Asistió? (No)", 0.14),
    ]
    xs = [x]
    for _, r in cols:
        xs.append(xs[-1] + w * r)

    y = y_top - header_h
    for i, (name, _) in enumerate(cols):
        draw_box(c, xs[i], y, xs[i + 1] - xs[i], header_h, fill_color=colors.darkgrey, stroke=1)
        c.setFillColor(colors.white)
        c.setFont(style.font_bold, 9)
        _draw_wrapped_text_block(
            c, xs[i], y, xs[i + 1] - xs[i], header_h,
            _wrap_text_lines(name, style.font_bold, 9, (xs[i + 1] - xs[i]) - 0.3 * cm),
            font_name=style.font_bold, font_size=9, leading=10,
            align="center", valign="middle", pad=0.0
        )
        c.setFillColor(colors.black)

    y_top = y

    for p in participants:
        y = y_top - row_h
        draw_box(c, xs[0], y, xs[1] - xs[0], row_h, fill_color=colors.white, stroke=1)
        draw_box(c, xs[1], y, xs[2] - xs[1], row_h, fill_color=colors.white, stroke=1)
        draw_box(c, xs[2], y, xs[3] - xs[2], row_h, fill_color=colors.white, stroke=1)
        draw_box(c, xs[3], y, xs[4] - xs[3], row_h, fill_color=colors.white, stroke=1)

        c.setFont(style.font, 9)
        c.drawString(xs[0] + 0.2 * cm, y + 0.30 * cm, str(p.get("area", "") or ""))
        c.drawString(xs[1] + 0.2 * cm, y + 0.30 * cm, str(p.get("responsable", "") or ""))

        cb = 0.38 * cm
        for j, key in enumerate(["si", "no"]):
            cell_x = xs[2 + j]
            cb_x = cell_x + (xs[3 + j] - cell_x) / 2.0 - cb / 2.0
            cb_y = y + row_h / 2.0 - cb / 2.0
            draw_box(c, cb_x, cb_y, cb, cb, fill_color=None, stroke=1)
            if bool(p.get(key, False)):
                c.saveState()
                _set_stroke(c, line_width=1.0)
                c.line(cb_x + 0.07 * cm, cb_y + 0.18 * cm, cb_x + 0.16 * cm, cb_y + 0.07 * cm)
                c.line(cb_x + 0.16 * cm, cb_y + 0.07 * cm, cb_x + 0.32 * cm, cb_y + 0.30 * cm)
                c.restoreState()

        y_top = y

    return y_top - 0.2 * cm

