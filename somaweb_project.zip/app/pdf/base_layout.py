# app/pdf/base_layout.py
from __future__ import annotations

import os
from dataclasses import dataclass
from typing import List, Tuple, Optional

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.pdfbase.pdfmetrics import stringWidth


# Colores 
ORANGE = colors.Color(0.96, 0.47, 0.13)  # barra naranjo
DARKGRAY = colors.Color(0.25, 0.25, 0.25)
LIGHTGRAY = colors.Color(0.92, 0.92, 0.92)
BLACK = colors.black
WHITE = colors.white


@dataclass
class PageStyle:
    pagesize: Tuple[float, float] = A4
    margin_left: float = 1.5 * cm
    margin_right: float = 1.5 * cm
    margin_top: float = 1.2 * cm
    margin_bottom: float = 1.2 * cm

    font: str = "Helvetica"
    font_bold: str = "Helvetica-Bold"


def image_exists(path: str) -> bool:
    try:
        return os.path.isfile(path) and os.path.getsize(path) > 0
    except Exception:
        return False


def draw_image_if_exists(c, path: str, x: float, y: float, w: float, h: float):
    if image_exists(path):
        c.drawImage(path, x, y, width=w, height=h, preserveAspectRatio=True, mask="auto")


def wrap_text(text: str, font_name: str, font_size: float, max_width: float) -> List[str]:
    
    if not text:
        return [""]

    lines_out: List[str] = []
    for raw_line in str(text).splitlines():
        words = raw_line.split()
        if not words:
            lines_out.append("")
            continue

        cur = words[0]
        for w in words[1:]:
            test = cur + " " + w
            if stringWidth(test, font_name, font_size) <= max_width:
                cur = test
            else:
                lines_out.append(cur)
                cur = w
        lines_out.append(cur)
    return lines_out


def draw_section_bar(c, x: float, y: float, w: float, h: float, title: str):
    c.setFillColor(ORANGE)
    c.setStrokeColor(BLACK)
    c.rect(x, y, w, h, stroke=0, fill=1)
    c.setFillColor(BLACK)
    c.setFont("Helvetica-Bold", 10)
    c.drawString(x + 0.3 * cm, y + 0.22 * cm, title.upper())


def draw_box(c, x: float, y: float, w: float, h: float, fill_color=None, stroke=1):
    if fill_color is not None:
        c.setFillColor(fill_color)
        c.rect(x, y, w, h, stroke=stroke, fill=1)
        c.setFillColor(BLACK)
    else:
        c.rect(x, y, w, h, stroke=stroke, fill=0)


def draw_table_grid(c, x: float, y: float, col_widths: List[float], row_heights: List[float], stroke=1):
    
    total_w = sum(col_widths)
    total_h = sum(row_heights)
    # borde
    c.setStrokeColor(BLACK)
    draw_box(c, x, y, total_w, total_h, fill_color=None, stroke=stroke)

    # verticales
    cx = x
    for w in col_widths[:-1]:
        cx += w
        c.line(cx, y, cx, y + total_h)

    # horizontales
    cy = y
    for h in row_heights[:-1]:
        cy += h
        c.line(x, cy, x + total_w, cy)


def draw_cell_text(
    c,
    x: float,
    y: float,
    w: float,
    h: float,
    text: str,
    font_name: str = "Helvetica",
    font_size: float = 9,
    padding: float = 0.2 * cm,
    valign: str = "middle",
):
    """
    Escribe texto ajustado. (x,y) bottom-left del cell.
    """
    c.setFont(font_name, font_size)
    max_w = max(1, w - 2 * padding)
    lines = wrap_text(text, font_name, font_size, max_w)

    # altura aprox por línea
    line_h = font_size * 1.15
    text_h = len(lines) * line_h

    if valign == "top":
        start_y = y + h - padding - line_h
    elif valign == "bottom":
        start_y = y + padding
    else:  # middle
        start_y = y + (h - text_h) / 2 + (len(lines) - 1) * line_h

    ty = start_y
    for ln in lines:
        c.drawString(x + padding, ty, ln)
        ty -= line_h


def draw_checkbox(c, x: float, y: float, size: float = 0.32 * cm, checked: bool = False):
    """
    Checkbox estilo PDF: cuadrado + check.
    (x,y) es esquina inferior izquierda del cuadrado.
    """
    c.setStrokeColor(BLACK)
    c.rect(x, y, size, size, stroke=1, fill=0)
    if checked:
        # check simple
        c.setLineWidth(1.2)
        c.line(x + size * 0.18, y + size * 0.55, x + size * 0.42, y + size * 0.25)
        c.line(x + size * 0.42, y + size * 0.25, x + size * 0.82, y + size * 0.78)
        c.setLineWidth(1.0)
